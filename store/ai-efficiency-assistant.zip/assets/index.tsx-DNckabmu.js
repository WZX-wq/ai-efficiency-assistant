(function(){function h(){const t=document.createElement("button");return t.className="ai-assistant-float-btn",t.title="AI 效率助手",t.innerHTML=`<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
  </svg>`,t}function v(){const t=document.createElement("div");t.className="ai-assistant-panel";const n=[{type:"rewrite",label:"改写",desc:"重新表达选中文字",iconClass:"rewrite",icon:"Aa"},{type:"expand",label:"扩写",desc:"扩展补充更多内容",iconClass:"expand",icon:"+"},{type:"translate",label:"翻译",desc:"中英文互译",iconClass:"translate",icon:"T"},{type:"summarize",label:"总结",desc:"提炼核心要点",iconClass:"summarize",icon:"S"}];return t.innerHTML=`
    <div class="ai-assistant-panel-header">AI 效率助手</div>
    ${n.map(e=>`
      <button class="ai-assistant-panel-item" data-action="${e.type}">
        <span class="ai-assistant-panel-item-icon ${e.iconClass}">${e.icon}</span>
        <div>
          <div class="ai-assistant-panel-item-label">${e.label}</div>
          <div class="ai-assistant-panel-item-desc">${e.desc}</div>
        </div>
      </button>
    `).join("")}
  `,t}let s,a,o="",c=!1;function w(){const t=window.getSelection();return!t||t.rangeCount===0||t.isCollapsed?null:t.getRangeAt(0).getBoundingClientRect()}function b(t){const n=t.right+8,e=t.top-8,i=window.innerWidth-48,l=Math.min(n,i),m=Math.max(e,8);s.style.left=`${l}px`,s.style.top=`${m}px`;const p=t.right+8,u=t.bottom+8,g=window.innerWidth-220,f=window.innerHeight-250;a.style.left=`${Math.min(p,g)}px`,a.style.top=`${Math.min(u,f)}px`}function x(){requestAnimationFrame(()=>{const t=window.getSelection(),n=t==null?void 0:t.toString().trim();if(n&&n.length>0){o=n;const e=w();e&&(b(e),s.classList.add("visible"))}else d()})}function y(t){const n=t.target;!s.contains(n)&&!a.contains(n)&&d()}function C(t){t.preventDefault(),t.stopPropagation(),c?r():E()}function L(t){const e=t.target.closest(".ai-assistant-panel-item");if(e){const i=e.dataset.action;i&&o&&(chrome.runtime.sendMessage({type:"AI_ACTION",action:i,selectedText:o}),d())}}function E(){a.classList.add("visible"),c=!0}function r(){a.classList.remove("visible"),c=!1}function d(){s.classList.remove("visible"),r(),o=""}function M(){s=h(),a=v(),document.body.appendChild(s),document.body.appendChild(a),document.addEventListener("mouseup",x),document.addEventListener("mousedown",y),s.addEventListener("click",C),a.addEventListener("click",L),chrome.runtime.onMessage.addListener((t,n,e)=>{if(t.type==="GET_SELECTED_TEXT"){const i=window.getSelection(),l=(i==null?void 0:i.toString().trim())||"";return e({selectedText:l}),!0}})}M();
})()
